import { Router} from "express";
import auth from "./auth";
import cRouter from "./companyRoutes"
import trouter from "./teamRouter"

const routes = Router();

routes.use("/auth", auth);
routes.use("/company", cRouter);
routes.use("/team/",trouter)

export default routes;
