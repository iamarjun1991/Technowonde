import { Router } from "express";
import {CompanyController} from "../controller/CompanyController";
import {TeamController} from "../controller/TeamController";
import { checkJwt } from "../middleware/checkJwt";




// export const Routes = [
//     {
//         method: "get",
//         route: "/company",
//         controller: CompanyController,
//         action: "all"
//     },
//     {
//         method: "post",
//         route: "/company",
//         controller: CompanyController,
//         action: "save"
//     },
//     {
//         method: "get",
//         route: "/company/:id",  
//         controller: CompanyController,
//         action: "one"
//     },
//     {
//         method: "get",
//         route: "/company/searchByName",  
//         controller: CompanyController,
//         action: "searchByName"
//     },
    
//     {
//         method: "get",
//         route: "/team",
//         controller: TeamController,
//         action: "all"
//     },
//     {
//         method: "post",
//         route: "/company/:id/team",
//         controller: TeamController,
//         action: "save"
//     },

//     {
//     method: "get",
//     route: "/users",
//     controller: UserController,
//     action: "all"
//    }, 
//    {
//     method: "get",
//     route: "/users/:id",
//     controller: UserController,
//     action: "one"
// }, {
//     method: "post",
//     route: "/users",
//     controller: UserController,
//     action: "save"
// }, {
//     method: "delete",
//     route: "/users/:id",
//     controller: UserController,
//     action: "remove"
// }];

const crouter = Router();
crouter.get("/all",[checkJwt], CompanyController.listAll);
crouter.post("/create",[checkJwt], CompanyController.create);
crouter.get("/search", [checkJwt],CompanyController.searchByName);
crouter.post("/:id/team/create",[checkJwt], TeamController.create);

export default crouter;




