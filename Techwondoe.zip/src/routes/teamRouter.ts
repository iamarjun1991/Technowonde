import { Router } from "express";

import {TeamController} from "../controller/TeamController";
import { checkJwt } from "../middleware/checkJwt";
const trouter = Router();
//Login route
trouter.get("/all", [checkJwt],TeamController.listAll);

export default trouter;




