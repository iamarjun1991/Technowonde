import {getRepository} from "typeorm";
import {Request, Response} from "express";
import {Company} from "../entity/Company";
import { Team } from "../entity/Team";

export class CompanyController {


    static listAll = async (req: Request, res: Response) => {
        //Get users from database
        const companyRepository = getRepository(Company);
        const cmp= await companyRepository.find()
        console.log(JSON.stringify(cmp));
        //return cmp;
      
        //Send the users object
        res.send(cmp);
      };
      
    static create =  async (request: Request, response: Response) => {
      
        const companyRepository = getRepository(Company);
        console.log("saved team")
        const stud = new Company();   
        stud.companyName= request.body.companyName;
        stud.companyCeo =request.body.companyCeo;
        stud.companyAddress =request.body.companyAddress;
        stud.companyInception = request.body.companyInception;
        if (request.body.team) {
            const teamRepository= getRepository(Team);
            const team = await teamRepository.save(request.body.team);
            stud.teams = [team];
        }
        console.log("**In Company services****: "+ JSON.stringify(request.body));
        await companyRepository.save(stud);
        response.send(stud);
    }

    static searchByName =  async (request: Request, response: Response) =>{
        const companyRepository = getRepository(Company);
        const seachValue= request.query.cName;
        const companyRes= await companyRepository.find({
            where: `(companyName like '%${seachValue}%')`
          });

          response.send(companyRes);
    }


}

