
import { getRepository } from "typeorm";
import { Request, Response } from "express";
import { Company } from "../entity/Company";
import { Team } from "../entity/Team";


export class TeamController {

    static create = async (request: Request, response: Response) => {
        const companyRepository = getRepository(Company);
        const teamRepository = getRepository(Team);
        const company = await companyRepository.findOne(request.params.id);
        console.log(": ********: " + JSON.stringify(company));
        if (company) {
            const newteam = await teamRepository.save(request.body);
            console.log("team created **********")
            let existingTeams = company.teams;
            existingTeams.push(newteam);
            request.body = company;
            console.log("ABout to call company services");
            companyRepository.save(request.body);
            response.send(newteam);
        } else {
            response.status(400).send("Invalid company ID");
        }
    }

    static listAll = async (request: Request, response: Response) => {
        const teamRepository = getRepository(Team);
        const cmp = await teamRepository.find({ relations: ['company'] });
        console.log(JSON.stringify(cmp));
        response.send(cmp);
    }

}