import {Entity, PrimaryGeneratedColumn, Column,ManyToOne,JoinColumn} from "typeorm";
import { Company } from "./Company";

@Entity()
export class Team {

    @PrimaryGeneratedColumn("uuid")
    uuid: string;

    @Column()
    TeamLeadName: string;

    @ManyToOne(type => Company, company => company.teams,{ eager: false }) 
    @JoinColumn()
    company: Company
}
