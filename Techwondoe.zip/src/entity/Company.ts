import {Entity, PrimaryGeneratedColumn, Column, OneToMany,JoinColumn} from "typeorm";
import { Team } from "./Team";

@Entity()
export class Company {

    @PrimaryGeneratedColumn("uuid")
    uuid: string;

    @Column()
    companyName: string;

    @Column()
    companyCeo: string;

    @Column()
    companyAddress: string;

    
    @Column()
    companyInception: Date;

    @OneToMany(type => Team, team => team.company,{ eager: true }) 
    @JoinColumn()
    teams: Team[];  

    

}
