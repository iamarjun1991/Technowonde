export default {
  jwtSecret: "@QEGTUI",
  username:'admin',
  password:'admin',
  id:1
};